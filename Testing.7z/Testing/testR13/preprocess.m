fileFolder=fullfile('D:\���ڶ�λ\WiFi�������ݼ���1��\HW\testD13');
dirOutput=dir(fullfile(fileFolder,'*.txt'));
fileNames={dirOutput.name}';
now=0;
posTD13=zeros(400,2);
for i=1:length(fileNames)
    now=now+1;
    str=fileNames{i};
    poscell=regexp(str,'\d*\.?\d*','match');
    x=str2num(poscell{1}); y=str2num(poscell{2});
    eval(['temp=importdata(''',fileNames{i},''');']);
    posTD13(now,1)=x;
    posTD13(now,2)=y;
    counterTD13{now}=cell2mat(cellfun(@(x){str2num(x)},temp.textdata(:,3)));
    BSSIDTD13{now}=temp.textdata(:,7);
    RSSITD13{now}=temp.data(:,1);
end